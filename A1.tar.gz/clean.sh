#!/bin/bash

rm -f *.o SimpleServer Persistent Helpers *~
